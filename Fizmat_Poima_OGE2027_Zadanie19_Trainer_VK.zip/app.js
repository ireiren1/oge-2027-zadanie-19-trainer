(() => {
  "use strict";

  const QUESTIONS = Array.isArray(window.TRAINER_QUESTIONS) ? window.TRAINER_QUESTIONS : [];
  const FREE_LIMIT = 15;
  const COMMUNITY_ID = 196676974;
  const DONUT_URL = `https://vk.ru/fizmat_poima?w=donut_payment-${COMMUNITY_ID}`;
  const STORAGE_KEY = "fizmat-poima-oge19-progress-v2";
  const ACCESS_SESSION_KEY = "fizmat-poima-oge19-donut-access";
  const MODE_NAMES = {
    demo: "Бесплатно · 15",
    full: "Все утверждения",
    sprint: "Спринт · 10",
    mistakes: "Работа над ошибками"
  };

  const screens = {
    home: document.getElementById("homeScreen"),
    quiz: document.getElementById("quizScreen"),
    results: document.getElementById("resultsScreen")
  };

  const elements = {
    brandButton: document.getElementById("brandButton"),
    mistakesCaption: document.getElementById("mistakesModeCaption"),
    modeName: document.getElementById("modeName"),
    progressText: document.getElementById("progressText"),
    progressBar: document.getElementById("progressBar"),
    topicChip: document.getElementById("topicChip"),
    questionNumber: document.getElementById("questionNumber"),
    statement: document.getElementById("quizStatement"),
    answerGrid: document.getElementById("answerGrid"),
    answerButtons: [...document.querySelectorAll("[data-answer]")],
    feedback: document.getElementById("feedback"),
    feedbackBadge: document.getElementById("feedbackBadge"),
    feedbackKicker: document.getElementById("feedbackKicker"),
    feedbackTitle: document.getElementById("feedbackTitle"),
    feedbackExplanation: document.getElementById("feedbackExplanation"),
    previousButton: document.getElementById("previousButton"),
    nextButton: document.getElementById("nextButton"),
    exitQuizButton: document.getElementById("exitQuizButton"),
    openNavigatorButton: document.getElementById("openNavigatorButton"),
    navigatorModal: document.getElementById("navigatorModal"),
    navigatorGrid: document.getElementById("navigatorGrid"),
    statsModal: document.getElementById("statsModal"),
    openStatsButton: document.getElementById("openStatsButton"),
    accessCard: document.getElementById("accessCard"),
    accessTitle: document.getElementById("accessTitle"),
    accessCaption: document.getElementById("accessCaption"),
    checkAccessButton: document.getElementById("checkAccessButton"),
    premiumModeCard: document.querySelector('[data-mode="full"]'),
    premiumBadge: document.querySelector(".premium-badge"),
    premiumModal: document.getElementById("premiumModal"),
    subscribeButton: document.getElementById("subscribeButton"),
    premiumCheckButton: document.getElementById("premiumCheckButton"),
    statsStudied: document.getElementById("statsStudied"),
    statsAnswers: document.getElementById("statsAnswers"),
    statsAccuracy: document.getElementById("statsAccuracy"),
    statsMistakes: document.getElementById("statsMistakes"),
    resetStatsButton: document.getElementById("resetStatsButton"),
    resultRing: document.getElementById("resultRing"),
    resultPercent: document.getElementById("resultPercent"),
    resultsTitle: document.getElementById("resultsTitle"),
    resultsSummary: document.getElementById("resultsSummary"),
    resultCorrect: document.getElementById("resultCorrect"),
    resultWrong: document.getElementById("resultWrong"),
    resultStreak: document.getElementById("resultStreak"),
    retryButton: document.getElementById("retryButton"),
    shareButton: document.getElementById("shareButton"),
    resultsHomeButton: document.getElementById("resultsHomeButton"),
    toast: document.getElementById("toast")
  };

  const state = {
    mode: "demo",
    queue: [],
    index: 0,
    answers: new Map(),
    progress: loadProgress(),
    premiumAccess: loadSessionAccess(),
    vkReady: false,
    toastTimer: null,
    lastFocusedElement: null
  };

  function loadSessionAccess() {
    try {
      return sessionStorage.getItem(ACCESS_SESSION_KEY) === "1";
    } catch {
      return false;
    }
  }

  function emptyProgress() {
    return {
      totalAnswers: 0,
      totalCorrect: 0,
      questions: {},
      mistakes: []
    };
  }

  function loadProgress() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (!parsed || typeof parsed !== "object") return emptyProgress();
      return {
        totalAnswers: Number(parsed.totalAnswers) || 0,
        totalCorrect: Number(parsed.totalCorrect) || 0,
        questions: parsed.questions && typeof parsed.questions === "object" ? parsed.questions : {},
        mistakes: Array.isArray(parsed.mistakes) ? parsed.mistakes.filter(Number.isInteger) : []
      };
    } catch {
      return emptyProgress();
    }
  }

  function saveProgress() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state.progress));
    } catch {
      // The trainer remains fully usable if storage is unavailable inside an iframe.
    }
    updateMistakesCaption();
  }

  function validateDataset() {
    const ids = new Set(QUESTIONS.map((question) => question.id));
    const valid = QUESTIONS.length === 85
      && ids.size === 85
      && QUESTIONS.every((question, index) => (
        question.id === index + 1
        && typeof question.text === "string"
        && question.text.trim().length > 10
        && typeof question.correct === "boolean"
        && typeof question.explanation === "string"
        && question.explanation.trim().length > 10
      ));

    if (!valid) {
      document.getElementById("mainContent").innerHTML = `
        <section class="results screen--active">
          <div class="results-card">
            <p class="eyebrow">ТЕХНИЧЕСКАЯ ОШИБКА</p>
            <h2>Не удалось загрузить задания</h2>
            <p class="results-card__summary">Обновите страницу. Если ошибка повторится, проверьте, что файл data.js находится рядом с index.html.</p>
          </div>
        </section>`;
      throw new Error("Invalid question dataset");
    }
  }

  function shuffle(items) {
    const copy = [...items];
    for (let index = copy.length - 1; index > 0; index -= 1) {
      const randomIndex = Math.floor(Math.random() * (index + 1));
      [copy[index], copy[randomIndex]] = [copy[randomIndex], copy[index]];
    }
    return copy;
  }

  function showScreen(name) {
    Object.entries(screens).forEach(([screenName, node]) => {
      node.classList.toggle("screen--active", screenName === name);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goHome() {
    closeAllModals();
    updateMistakesCaption();
    showScreen("home");
  }

  function startMode(mode) {
    let queue;

    if (mode === "full" && !state.premiumAccess) {
      openModal(elements.premiumModal);
      return;
    }

    if (mode === "demo") {
      queue = QUESTIONS.slice(0, FREE_LIMIT);
    } else if (mode === "full") {
      queue = [...QUESTIONS];
    } else if (mode === "sprint") {
      queue = shuffle(getAvailableQuestions()).slice(0, 10);
    } else {
      const mistakeIds = new Set(state.progress.mistakes);
      queue = shuffle(getAvailableQuestions().filter((question) => mistakeIds.has(question.id)));
      if (queue.length === 0) {
        showToast("Ошибок для повтора пока нет. Начните с полного режима или спринта.");
        return;
      }
    }

    state.mode = mode;
    state.queue = queue;
    state.index = 0;
    state.answers = new Map();
    elements.modeName.textContent = MODE_NAMES[mode];
    showScreen("quiz");
    renderQuestion();
  }

  function getAvailableQuestions() {
    return state.premiumAccess ? QUESTIONS : QUESTIONS.slice(0, FREE_LIMIT);
  }

  function currentQuestion() {
    return state.queue[state.index];
  }

  function renderQuestion() {
    const question = currentQuestion();
    if (!question) return;

    const answered = state.answers.get(question.id);
    elements.progressText.textContent = `${state.index + 1} из ${state.queue.length}`;
    elements.progressBar.style.width = `${((state.index + 1) / state.queue.length) * 100}%`;
    elements.topicChip.textContent = question.topic;
    elements.questionNumber.textContent = `№ ${question.id}`;
    elements.statement.textContent = question.text;
    elements.previousButton.disabled = state.index === 0;
    elements.nextButton.disabled = !answered;
    elements.nextButton.innerHTML = state.index === state.queue.length - 1
      ? "Завершить <span aria-hidden=\"true\">→</span>"
      : "Следующее <span aria-hidden=\"true\">→</span>";

    resetAnswerVisuals();
    if (answered) applyAnswerVisuals(question, answered);
  }

  function resetAnswerVisuals() {
    elements.answerButtons.forEach((button) => {
      button.disabled = false;
      button.classList.remove("is-correct", "is-wrong", "is-muted");
      button.removeAttribute("aria-pressed");
    });
    elements.feedback.classList.remove("is-visible", "is-correct", "is-wrong");
    elements.feedbackBadge.textContent = "";
    elements.feedbackKicker.textContent = "";
    elements.feedbackTitle.textContent = "";
    elements.feedbackExplanation.textContent = "";
  }

  function answerQuestion(userAnswer) {
    const question = currentQuestion();
    if (!question || state.answers.has(question.id)) return;

    const isCorrect = userAnswer === question.correct;
    const response = { userAnswer, isCorrect };
    state.answers.set(question.id, response);
    recordAnswer(question.id, isCorrect);
    applyAnswerVisuals(question, response);
    elements.nextButton.disabled = false;
    runHaptic(isCorrect ? "success" : "error");
  }

  function recordAnswer(questionId, isCorrect) {
    const previous = state.progress.questions[questionId] || { attempts: 0, correct: 0 };
    state.progress.questions[questionId] = {
      attempts: previous.attempts + 1,
      correct: previous.correct + (isCorrect ? 1 : 0)
    };
    state.progress.totalAnswers += 1;
    state.progress.totalCorrect += isCorrect ? 1 : 0;

    const mistakes = new Set(state.progress.mistakes);
    if (isCorrect) mistakes.delete(questionId);
    else mistakes.add(questionId);
    state.progress.mistakes = [...mistakes].sort((a, b) => a - b);
    saveProgress();
  }

  function applyAnswerVisuals(question, response) {
    elements.answerButtons.forEach((button) => {
      const buttonAnswer = button.dataset.answer === "true";
      button.disabled = true;
      button.setAttribute("aria-pressed", String(buttonAnswer === response.userAnswer));

      if (buttonAnswer === question.correct) {
        button.classList.add("is-correct");
      } else if (buttonAnswer === response.userAnswer) {
        button.classList.add("is-wrong");
      } else {
        button.classList.add("is-muted");
      }
    });

    elements.feedback.classList.add("is-visible", response.isCorrect ? "is-correct" : "is-wrong");
    elements.feedbackBadge.textContent = response.isCorrect ? "✓" : "!";
    elements.feedbackKicker.textContent = response.isCorrect ? "Ответ принят" : "Разберём ловушку";
    elements.feedbackTitle.textContent = response.isCorrect
      ? `Верно! Правильный ответ — ${question.correct ? "«верно»" : "«неверно»"}.`
      : `Правильный ответ — ${question.correct ? "«верно»" : "«неверно»"}.`;
    elements.feedbackExplanation.textContent = question.explanation;
  }

  function goNext() {
    const question = currentQuestion();
    if (!question || !state.answers.has(question.id)) return;

    if (state.index >= state.queue.length - 1) {
      const firstUnanswered = state.queue.findIndex((item) => !state.answers.has(item.id));
      if (firstUnanswered !== -1) {
        const remaining = state.queue.length - state.answers.size;
        state.index = firstUnanswered;
        renderQuestion();
        showToast(`Осталось ответить: ${remaining}.`);
        return;
      }
      showResults();
      return;
    }

    state.index += 1;
    renderQuestion();
  }

  function goPrevious() {
    if (state.index === 0) return;
    state.index -= 1;
    renderQuestion();
  }

  function calculateBestStreak() {
    let current = 0;
    let best = 0;
    state.queue.forEach((question) => {
      const response = state.answers.get(question.id);
      if (response?.isCorrect) {
        current += 1;
        best = Math.max(best, current);
      } else {
        current = 0;
      }
    });
    return best;
  }

  function showResults() {
    const responses = [...state.answers.values()];
    const correct = responses.filter((response) => response.isCorrect).length;
    const total = state.queue.length;
    const wrong = total - correct;
    const percent = Math.round((correct / total) * 100);
    const bestStreak = calculateBestStreak();

    let title = "Продолжим разбираться";
    let summary = "Повторите ошибки: каждый контрпример превращает формулировку в понятное правило.";
    if (percent >= 90) {
      title = "Отличная работа!";
      summary = "Вы уверенно отличаете теоремы от похожих, но неверных формулировок.";
    } else if (percent >= 75) {
      title = "Очень хороший результат";
      summary = "Основа крепкая. Разберите оставшиеся ошибки — и ловушки задания №19 перестанут мешать.";
    } else if (percent >= 60) {
      title = "Хорошее начало";
      summary = "Большая часть правил уже узнаётся. Режим повторения поможет закрепить сложные формулировки.";
    }

    elements.resultRing.style.setProperty("--score", String(percent));
    elements.resultPercent.textContent = `${percent}%`;
    elements.resultsTitle.textContent = title;
    elements.resultsSummary.textContent = summary;
    elements.resultCorrect.textContent = String(correct);
    elements.resultWrong.textContent = String(wrong);
    elements.resultStreak.textContent = String(bestStreak);
    showScreen("results");
    runHaptic(percent >= 75 ? "success" : "warning");
  }

  function openNavigator() {
    elements.navigatorGrid.replaceChildren();
    state.queue.forEach((question, queueIndex) => {
      const button = document.createElement("button");
      const response = state.answers.get(question.id);
      button.type = "button";
      button.className = "navigator-button";
      button.textContent = String(question.id);
      button.setAttribute("aria-label", `Перейти к утверждению №${question.id}`);
      if (queueIndex === state.index) button.classList.add("is-current");
      if (response?.isCorrect) button.classList.add("is-correct");
      if (response && !response.isCorrect) button.classList.add("is-wrong");
      button.addEventListener("click", () => {
        state.index = queueIndex;
        renderQuestion();
        closeModal(elements.navigatorModal);
      });
      elements.navigatorGrid.append(button);
    });
    openModal(elements.navigatorModal);
  }

  function updateStats() {
    const availableIds = new Set(getAvailableQuestions().map((question) => String(question.id)));
    const studied = Object.keys(state.progress.questions).filter((id) => availableIds.has(id)).length;
    const accuracy = state.progress.totalAnswers > 0
      ? `${Math.round((state.progress.totalCorrect / state.progress.totalAnswers) * 100)}%`
      : "—";
    elements.statsStudied.textContent = `${studied} / ${getAvailableQuestions().length}`;
    elements.statsAnswers.textContent = String(state.progress.totalAnswers);
    elements.statsAccuracy.textContent = accuracy;
    elements.statsMistakes.textContent = String(state.progress.mistakes.length);
  }

  function updateMistakesCaption() {
    const availableIds = new Set(getAvailableQuestions().map((question) => question.id));
    const count = state.progress.mistakes.filter((id) => availableIds.has(id)).length;
    elements.mistakesCaption.textContent = count === 0
      ? "Ошибок пока нет"
      : `${pluralize(count, "утверждение", "утверждения", "утверждений")} на повторе`;
  }

  function pluralize(number, one, few, many) {
    const absolute = Math.abs(number) % 100;
    const last = absolute % 10;
    const form = absolute > 10 && absolute < 20 ? many : last === 1 ? one : last >= 2 && last <= 4 ? few : many;
    return `${number} ${form}`;
  }

  function resetStats() {
    const confirmed = window.confirm("Сбросить всю статистику и список ошибок? Это действие нельзя отменить.");
    if (!confirmed) return;
    state.progress = emptyProgress();
    saveProgress();
    updateStats();
    showToast("Статистика сброшена.");
  }

  function openModal(modal) {
    state.lastFocusedElement = document.activeElement;
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    const firstButton = modal.querySelector("button:not(.modal__backdrop)");
    window.setTimeout(() => firstButton?.focus(), 30);
  }

  function closeModal(modal) {
    if (!modal.classList.contains("is-open")) return;
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    if (!document.querySelector(".modal.is-open")) document.body.classList.remove("modal-open");
    state.lastFocusedElement?.focus?.();
  }

  function closeAllModals() {
    document.querySelectorAll(".modal.is-open").forEach(closeModal);
  }

  function showToast(message) {
    elements.toast.textContent = message;
    elements.toast.classList.add("is-visible");
    window.clearTimeout(state.toastTimer);
    state.toastTimer = window.setTimeout(() => elements.toast.classList.remove("is-visible"), 3200);
  }

  async function shareResult() {
    const percent = elements.resultPercent.textContent;
    const correct = elements.resultCorrect.textContent;
    const total = state.queue.length;
    const text = `Мой результат в тренажёре «ОГЭ-2027 · Задание №19»: ${correct} из ${total} (${percent}). Физмат Пойма`;
    const shareData = { title: "ОГЭ-2027 · Задание №19", text, url: window.location.href };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(`${text}\n${window.location.href}`);
        showToast("Результат и ссылка скопированы.");
      } else {
        showToast(text);
      }
    } catch (error) {
      if (error?.name !== "AbortError") showToast("Не удалось открыть меню публикации.");
    }
  }

  async function initVKBridge() {
    if (!window.vkBridge?.send) return;
    try {
      await window.vkBridge.send("VKWebAppInit");
      state.vkReady = true;
      window.vkBridge.send("VKWebAppSetTitle", { title: "ОГЭ №19 · Физмат Пойма" }).catch(() => {});
    } catch {
      // Outside VK the app works as an ordinary responsive website.
    }
  }

  function setPremiumAccess(enabled) {
    state.premiumAccess = Boolean(enabled);
    try {
      if (state.premiumAccess) sessionStorage.setItem(ACCESS_SESSION_KEY, "1");
      else sessionStorage.removeItem(ACCESS_SESSION_KEY);
    } catch {
      // Session storage is an optional convenience; VK remains the source of truth.
    }

    elements.accessCard.classList.toggle("is-active", state.premiumAccess);
    elements.premiumModeCard.classList.toggle("is-unlocked", state.premiumAccess);
    elements.accessTitle.textContent = state.premiumAccess ? "Полный доступ открыт" : "Полный доступ по VK Donut";
    elements.accessCaption.textContent = state.premiumAccess
      ? "Доступны все 85 утверждений и режимы"
      : "Уровень «На тренажёры» · 150 ₽ в месяц";
    elements.checkAccessButton.textContent = state.premiumAccess ? "Доступ активен" : "Проверить подписку";
    elements.premiumBadge.textContent = state.premiumAccess ? "ДОСТУП" : "DONUT";
    updateMistakesCaption();
  }

  async function checkDonutAccess() {
    const buttons = [elements.checkAccessButton, elements.premiumCheckButton];
    buttons.forEach((button) => {
      button.disabled = true;
      button.dataset.originalText = button.textContent;
      button.textContent = "Проверяем…";
    });

    try {
      if (!window.vkBridge?.send || !state.vkReady) {
        throw new Error("VK_NOT_READY");
      }

      const launchParams = await window.vkBridge.send("VKWebAppGetLaunchParams");
      const queryAppId = new URLSearchParams(window.location.search).get("vk_app_id");
      const appId = Number(launchParams?.vk_app_id || queryAppId);
      if (!Number.isInteger(appId) || appId <= 0) throw new Error("VK_APP_ID_MISSING");

      const auth = await window.vkBridge.send("VKWebAppGetAuthToken", {
        app_id: appId,
        scope: ""
      });
      if (!auth?.access_token) throw new Error("VK_AUTH_FAILED");

      const apiResult = await window.vkBridge.send("VKWebAppCallAPIMethod", {
        method: "donut.isDon",
        request_id: `donut-${Date.now()}`,
        params: {
          owner_id: -COMMUNITY_ID,
          access_token: auth.access_token,
          v: "5.199"
        }
      });

      const response = apiResult?.response;
      const isDon = response === 1 || response === true || response?.is_don === 1 || response?.is_don === true;
      setPremiumAccess(isDon);

      if (isDon) {
        closeModal(elements.premiumModal);
        showToast("Подписка подтверждена. Все 85 утверждений открыты!");
        runHaptic("success");
      } else {
        openModal(elements.premiumModal);
        showToast("Активная подписка «На тренажёры» пока не найдена.");
      }
    } catch {
      openModal(elements.premiumModal);
      showToast("Проверка подписки доступна при запуске тренажёра внутри ВКонтакте.");
    } finally {
      buttons.forEach((button) => {
        button.disabled = false;
        button.textContent = state.premiumAccess ? "Доступ активен" : button.dataset.originalText;
        delete button.dataset.originalText;
      });
    }
  }

  function openDonutSubscription() {
    const opened = window.open(DONUT_URL, "_blank", "noopener,noreferrer");
    if (!opened) window.location.href = DONUT_URL;
  }

  function runHaptic(type) {
    if (!window.vkBridge?.send) return;
    window.vkBridge.send("VKWebAppTapticNotificationOccurred", { type }).catch(() => {});
  }

  function registerServiceWorker() {
    if (!("serviceWorker" in navigator) || !window.isSecureContext) return;
    navigator.serviceWorker.register("service-worker.js").catch(() => {});
  }

  function bindEvents() {
    document.querySelectorAll("[data-mode]").forEach((button) => {
      button.addEventListener("click", () => startMode(button.dataset.mode));
    });

    elements.answerButtons.forEach((button) => {
      button.addEventListener("click", () => answerQuestion(button.dataset.answer === "true"));
    });

    elements.nextButton.addEventListener("click", goNext);
    elements.previousButton.addEventListener("click", goPrevious);
    elements.exitQuizButton.addEventListener("click", goHome);
    elements.brandButton.addEventListener("click", goHome);
    elements.openNavigatorButton.addEventListener("click", openNavigator);
    elements.openStatsButton.addEventListener("click", () => {
      updateStats();
      openModal(elements.statsModal);
    });
    elements.resetStatsButton.addEventListener("click", resetStats);
    elements.checkAccessButton.addEventListener("click", checkDonutAccess);
    elements.premiumCheckButton.addEventListener("click", checkDonutAccess);
    elements.subscribeButton.addEventListener("click", openDonutSubscription);
    elements.retryButton.addEventListener("click", () => startMode(state.mode));
    elements.shareButton.addEventListener("click", shareResult);
    elements.resultsHomeButton.addEventListener("click", goHome);

    document.querySelectorAll("[data-close-modal]").forEach((button) => {
      button.addEventListener("click", () => closeModal(button.closest(".modal")));
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        closeAllModals();
        return;
      }
      if (!screens.quiz.classList.contains("screen--active") || document.querySelector(".modal.is-open")) return;

      const question = currentQuestion();
      const answered = question && state.answers.has(question.id);
      if (!answered && (event.key.toLowerCase() === "v" || event.key === "ArrowLeft")) answerQuestion(true);
      if (!answered && (event.key.toLowerCase() === "n" || event.key === "ArrowRight")) answerQuestion(false);
      if (answered && (event.key === "Enter" || event.key === "ArrowDown")) goNext();
    });
  }

  validateDataset();
  bindEvents();
  setPremiumAccess(state.premiumAccess);
  updateMistakesCaption();
  window.addEventListener("vkbridge-ready", initVKBridge, { once: true });
  initVKBridge();
  registerServiceWorker();
})();
