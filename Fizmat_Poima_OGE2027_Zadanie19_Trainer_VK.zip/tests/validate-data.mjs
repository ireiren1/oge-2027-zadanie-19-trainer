import fs from "node:fs";
import path from "node:path";
import vm from "node:vm";
import { fileURLToPath } from "node:url";

const testDirectory = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(testDirectory, "..");
const source = fs.readFileSync(path.join(root, "data.js"), "utf8");
const context = { window: {} };
vm.createContext(context);
vm.runInContext(source, context);

const questions = context.window.TRAINER_QUESTIONS;
const expectedTrueIds = [
  1, 5, 10, 12, 19, 31, 35, 40, 49, 58, 59, 60, 62, 63, 64, 65,
  66, 67, 68, 69, 70, 71, 72, 73, 75, 76, 77, 78, 79, 82, 85
];

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

assert(Array.isArray(questions), "TRAINER_QUESTIONS must be an array");
assert(questions.length === 85, `Expected 85 questions, received ${questions.length}`);
assert(new Set(questions.map((item) => item.id)).size === 85, "Question ids must be unique");

questions.forEach((question, index) => {
  assert(question.id === index + 1, `Question ${index + 1} has an invalid id`);
  assert(typeof question.text === "string" && question.text.trim().length > 10, `Question ${question.id} has no text`);
  assert(typeof question.correct === "boolean", `Question ${question.id} has no boolean answer`);
  assert(typeof question.topic === "string" && question.topic.trim(), `Question ${question.id} has no topic`);
  assert(typeof question.explanation === "string" && question.explanation.trim().length > 10, `Question ${question.id} has no explanation`);
});

const trueIds = questions.filter((question) => question.correct).map((question) => question.id);
assert(JSON.stringify(trueIds) === JSON.stringify(expectedTrueIds), `Unexpected true-answer list: ${trueIds.join(", ")}`);

for (const filename of ["index.html", "styles.css", "app.js", "manifest.webmanifest", "service-worker.js"]) {
  assert(fs.existsSync(path.join(root, filename)), `Missing ${filename}`);
}

console.log(`Validated ${questions.length} questions; ${trueIds.length} true and ${questions.length - trueIds.length} false.`);
