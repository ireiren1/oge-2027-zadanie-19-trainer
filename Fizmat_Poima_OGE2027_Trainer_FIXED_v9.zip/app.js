(() => {
  "use strict";

  const QUESTIONS = Array.isArray(window.TRAINER_QUESTIONS) ? window.TRAINER_QUESTIONS : [];
  const FREE_LIMIT = 15;
  const VK_APP_ID = 54782047;
  const VK_APP_URL = `https://vk.com/app${VK_APP_ID}`;
  const COMMUNITY_ID = 196676974;
  const OWNER_VK_ID = 12605677;
  const COMMUNITY_MANAGER_ROLES = new Set(["admin", "editor", "moder", "creator", "owner"]);
  const DONUT_URL = "https://vk.com/donut/fizmat_poima";
  const STORAGE_KEY = "fizmat-poima-oge19-progress-v2";
  const VK_PROGRESS_KEY = "oge19_progress_v1";
  const ACCESS_SESSION_KEY = "fizmat-poima-oge19-donut-access";
  const MODE_NAMES = {
    demo: "Бесплатно · 15",
    full: "Все утверждения",
    sprint: "Спринт · 10",
    mistakes: "Работа над ошибками"
  };

  const screens = {
    home: document.getElementById("homeScreen"),
    quiz: document.getElementById("quizScreen"),
    results: document.getElementById("resultsScreen")
  };

  const elements = {
    brandButton: document.getElementById("brandButton"),
    mistakesCaption: document.getElementById("mistakesModeCaption"),
    modeName: document.getElementById("modeName"),
    progressText: document.getElementById("progressText"),
    progressBar: document.getElementById("progressBar"),
    topicChip: document.getElementById("topicChip"),
    questionNumber: document.getElementById("questionNumber"),
    statement: document.getElementById("quizStatement"),
    answerGrid: document.getElementById("answerGrid"),
    answerButtons: [...document.querySelectorAll("[data-answer]")],
    feedback: document.getElementById("feedback"),
    feedbackBadge: document.getElementById("feedbackBadge"),
    feedbackKicker: document.getElementById("feedbackKicker"),
    feedbackTitle: document.getElementById("feedbackTitle"),
    feedbackExplanation: document.getElementById("feedbackExplanation"),
    previousButton: document.getElementById("previousButton"),
    nextButton: document.getElementById("nextButton"),
    exitQuizButton: document.getElementById("exitQuizButton"),
    openNavigatorButton: document.getElementById("openNavigatorButton"),
    navigatorModal: document.getElementById("navigatorModal"),
    navigatorGrid: document.getElementById("navigatorGrid"),
    statsModal: document.getElementById("statsModal"),
    openStatsButton: document.getElementById("openStatsButton"),
    accessCard: document.getElementById("accessCard"),
    accessTitle: document.getElementById("accessTitle"),
    accessCaption: document.getElementById("accessCaption"),
    checkAccessButton: document.getElementById("checkAccessButton"),
    premiumModeCard: document.querySelector('[data-mode="full"]'),
    premiumBadge: document.querySelector(".premium-badge"),
    premiumModal: document.getElementById("premiumModal"),
    subscribeButton: document.getElementById("subscribeButton"),
    premiumCheckButton: document.getElementById("premiumCheckButton"),
    statsStudied: document.getElementById("statsStudied"),
    statsAnswers: document.getElementById("statsAnswers"),
    statsAccuracy: document.getElementById("statsAccuracy"),
    statsMistakes: document.getElementById("statsMistakes"),
    resetStatsButton: document.getElementById("resetStatsButton"),
    resultRing: document.getElementById("resultRing"),
    resultPercent: document.getElementById("resultPercent"),
    resultsTitle: document.getElementById("resultsTitle"),
    resultsSummary: document.getElementById("resultsSummary"),
    resultCorrect: document.getElementById("resultCorrect"),
    resultWrong: document.getElementById("resultWrong"),
    resultStreak: document.getElementById("resultStreak"),
    retryButton: document.getElementById("retryButton"),
    shareButton: document.getElementById("shareButton"),
    resultsHomeButton: document.getElementById("resultsHomeButton"),
    toast: document.getElementById("toast")
  };

  const state = {
    mode: "demo",
    queue: [],
    index: 0,
    answers: new Map(),
    progress: loadProgress(),
    premiumAccess: loadSessionAccess(),
    accessSource: null,
    vkReady: false,
    toastTimer: null,
    lastFocusedElement: null,
    progressSaveTimer: null
  };

  function loadSessionAccess() {
    try {
      return sessionStorage.getItem(ACCESS_SESSION_KEY) === "1";
    } catch {
      return false;
    }
  }

  function emptyProgress() {
    return {
      totalAnswers: 0,
      totalCorrect: 0,
      questions: {},
      mistakes: [],
      updatedAt: 0
    };
  }

  function loadProgress() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
      if (!parsed || typeof parsed !== "object") return emptyProgress();
      return {
        totalAnswers: Number(parsed.totalAnswers) || 0,
        totalCorrect: Number(parsed.totalCorrect) || 0,
        questions: parsed.questions && typeof parsed.questions === "object" ? parsed.questions : {},
        mistakes: Array.isArray(parsed.mistakes) ? parsed.mistakes.filter(Number.isInteger) : [],
        updatedAt: Number(parsed.updatedAt) || 0
      };
    } catch {
      return emptyProgress();
    }
  }

  function saveProgress() {
    state.progress.updatedAt = Date.now();
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state.progress));
    } catch {
      // The trainer remains fully usable if storage is unavailable inside an iframe.
    }
    updateMistakesCaption();
    updateProgressSummary();
    queueVKProgressSave();
  }

  function updateProgressSummary() {
    const availableIds = new Set(getAvailableQuestions().map((question) => String(question.id)));
    const studied = Object.keys(state.progress.questions).filter((id) => availableIds.has(id)).length;
    elements.openStatsButton.textContent = `Мой прогресс · ${studied}/${getAvailableQuestions().length}`;
  }

  function queueVKProgressSave() {
    if (!state.vkReady || !window.vkBridge?.send) return;
    window.clearTimeout(state.progressSaveTimer);
    state.progressSaveTimer = window.setTimeout(async () => {
      try {
        await window.vkBridge.send("VKWebAppStorageSet", {
          key: VK_PROGRESS_KEY,
          value: JSON.stringify(state.progress)
        });
      } catch {
        // Local storage remains available if account storage is temporarily unavailable.
      }
    }, 250);
  }

  async function loadVKProgress() {
    if (!state.vkReady || !window.vkBridge?.send) return;
    try {
      const result = await window.vkBridge.send("VKWebAppStorageGet", { keys: [VK_PROGRESS_KEY] });
      const item = Array.isArray(result?.keys)
        ? result.keys.find((entry) => entry?.key === VK_PROGRESS_KEY)
        : null;
      if (!item?.value) return;
      const remote = JSON.parse(item.value);
      if (!remote || typeof remote !== "object") return;
      if ((Number(remote.updatedAt) || 0) < (Number(state.progress.updatedAt) || 0)) {
        queueVKProgressSave();
        return;
      }
      state.progress = {
        totalAnswers: Number(remote.totalAnswers) || 0,
        totalCorrect: Number(remote.totalCorrect) || 0,
        questions: remote.questions && typeof remote.questions === "object" ? remote.questions : {},
        mistakes: Array.isArray(remote.mistakes) ? remote.mistakes.filter(Number.isInteger) : [],
        updatedAt: Number(remote.updatedAt) || 0
      };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(state.progress));
      } catch {
        // Account storage is already loaded, so local mirroring is optional.
      }
      updateMistakesCaption();
      updateProgressSummary();
    } catch {
      // Continue with local progress if VK account storage cannot be read.
    }
  }

  function validateDataset() {
    const ids = new Set(QUESTIONS.map((question) => question.id));
    const valid = QUESTIONS.length === 85
      && ids.size === 85
      && QUESTIONS.every((question, index) => (
        question.id === index + 1
        && typeof question.text === "string"
        && question.text.trim().length > 10
        && typeof question.correct === "boolean"
        && typeof question.explanation === "string"
        && question.explanation.trim().length > 10
      ));

    if (!valid) {
      document.getElementById("mainContent").innerHTML = `
        <section class="results screen--active">
          <div class="results-card">
            <p class="eyebrow">ТЕХНИЧЕСКАЯ ОШИБКА</p>
            <h2>Не удалось загрузить задания</h2>
            <p class="results-card__summary">Обновите страницу. Если ошибка повторится, проверьте, что файл data.js находится рядом с index.html.</p>
          </div>
        </section>`;
      throw new Error("Invalid question dataset");
    }
  }

  function shuffle(items) {
    const copy = [...items];
    for (let index = copy.length - 1; index > 0; index -= 1) {
      const randomIndex = Math.floor(Math.random() * (index + 1));
      [copy[index], copy[randomIndex]] = [copy[randomIndex], copy[index]];
    }
    return copy;
  }

  function showScreen(name) {
    Object.entries(screens).forEach(([screenName, node]) => {
      node.classList.toggle("screen--active", screenName === name);
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function goHome() {
    closeAllModals();
    updateMistakesCaption();
    showScreen("home");
  }

  function startMode(mode) {
    let queue;

    if (mode === "full" && !state.premiumAccess) {
      openModal(elements.premiumModal);
      return;
    }

    if (mode === "demo") {
      queue = QUESTIONS.slice(0, FREE_LIMIT);
    } else if (mode === "full") {
      queue = [...QUESTIONS];
    } else if (mode === "sprint") {
      queue = shuffle(getAvailableQuestions()).slice(0, 10);
    } else {
      const mistakeIds = new Set(state.progress.mistakes);
      queue = shuffle(getAvailableQuestions().filter((question) => mistakeIds.has(question.id)));
      if (queue.length === 0) {
        showToast("Ошибок для повтора пока нет. Начните с полного режима или спринта.");
        return;
      }
    }

    state.mode = mode;
    state.queue = queue;
    state.index = 0;
    state.answers = new Map();
    elements.modeName.textContent = MODE_NAMES[mode];
    showScreen("quiz");
    renderQuestion();
  }

  function getAvailableQuestions() {
    return state.premiumAccess ? QUESTIONS : QUESTIONS.slice(0, FREE_LIMIT);
  }

  function currentQuestion() {
    return state.queue[state.index];
  }

  function renderQuestion() {
    const question = currentQuestion();
    if (!question) return;

    const answered = state.answers.get(question.id);
    elements.progressText.textContent = `${state.index + 1} из ${state.queue.length}`;
    elements.progressBar.style.width = `${((state.index + 1) / state.queue.length) * 100}%`;
    elements.topicChip.textContent = question.topic;
    elements.questionNumber.textContent = `№ ${question.id}`;
    elements.statement.textContent = question.text;
    elements.previousButton.disabled = state.index === 0;
    elements.nextButton.disabled = !answered;
    elements.nextButton.innerHTML = state.index === state.queue.length - 1
      ? "Завершить <span aria-hidden=\"true\">→</span>"
      : "Следующее <span aria-hidden=\"true\">→</span>";

    resetAnswerVisuals();
    if (answered) applyAnswerVisuals(question, answered);
  }

  function resetAnswerVisuals() {
    elements.answerButtons.forEach((button) => {
      button.disabled = false;
      button.classList.remove("is-correct", "is-wrong", "is-muted");
      button.removeAttribute("aria-pressed");
    });
    elements.feedback.classList.remove("is-visible", "is-correct", "is-wrong");
    elements.feedbackBadge.textContent = "";
    elements.feedbackKicker.textContent = "";
    elements.feedbackTitle.textContent = "";
    elements.feedbackExplanation.textContent = "";
  }

  function answerQuestion(userAnswer) {
    const question = currentQuestion();
    if (!question || state.answers.has(question.id)) return;

    const isCorrect = userAnswer === question.correct;
    const response = { userAnswer, isCorrect };
    state.answers.set(question.id, response);
    recordAnswer(question.id, isCorrect);
    applyAnswerVisuals(question, response);
    elements.nextButton.disabled = false;
    runHaptic(isCorrect ? "success" : "error");
  }

  function recordAnswer(questionId, isCorrect) {
    const previous = state.progress.questions[questionId] || { attempts: 0, correct: 0 };
    state.progress.questions[questionId] = {
      attempts: previous.attempts + 1,
      correct: previous.correct + (isCorrect ? 1 : 0)
    };
    state.progress.totalAnswers += 1;
    state.progress.totalCorrect += isCorrect ? 1 : 0;

    const mistakes = new Set(state.progress.mistakes);
    if (isCorrect) mistakes.delete(questionId);
    else mistakes.add(questionId);
    state.progress.mistakes = [...mistakes].sort((a, b) => a - b);
    saveProgress();
  }

  function applyAnswerVisuals(question, response) {
    elements.answerButtons.forEach((button) => {
      const buttonAnswer = button.dataset.answer === "true";
      button.disabled = true;
      button.setAttribute("aria-pressed", String(buttonAnswer === response.userAnswer));

      if (buttonAnswer === question.correct) {
        button.classList.add("is-correct");
      } else if (buttonAnswer === response.userAnswer) {
        button.classList.add("is-wrong");
      } else {
        button.classList.add("is-muted");
      }
    });

    elements.feedback.classList.add("is-visible", response.isCorrect ? "is-correct" : "is-wrong");
    elements.feedbackBadge.textContent = response.isCorrect ? "✓" : "!";
    elements.feedbackKicker.textContent = response.isCorrect ? "Ответ принят" : "Разберём ловушку";
    elements.feedbackTitle.textContent = response.isCorrect
      ? `Верно! Правильный ответ — ${question.correct ? "«верно»" : "«неверно»"}.`
      : `Правильный ответ — ${question.correct ? "«верно»" : "«неверно»"}.`;
    elements.feedbackExplanation.textContent = question.explanation;
  }

  function goNext() {
    const question = currentQuestion();
    if (!question || !state.answers.has(question.id)) return;

    if (state.index >= state.queue.length - 1) {
      const firstUnanswered = state.queue.findIndex((item) => !state.answers.has(item.id));
      if (firstUnanswered !== -1) {
        const remaining = state.queue.length - state.answers.size;
        state.index = firstUnanswered;
        renderQuestion();
        showToast(`Осталось ответить: ${remaining}.`);
        return;
      }
      showResults();
      return;
    }

    state.index += 1;
    renderQuestion();
  }

  function goPrevious() {
    if (state.index === 0) return;
    state.index -= 1;
    renderQuestion();
  }

  function calculateBestStreak() {
    let current = 0;
    let best = 0;
    state.queue.forEach((question) => {
      const response = state.answers.get(question.id);
      if (response?.isCorrect) {
        current += 1;
        best = Math.max(best, current);
      } else {
        current = 0;
      }
    });
    return best;
  }

  function showResults() {
    const responses = [...state.answers.values()];
    const correct = responses.filter((response) => response.isCorrect).length;
    const total = state.queue.length;
    const wrong = total - correct;
    const percent = Math.round((correct / total) * 100);
    const bestStreak = calculateBestStreak();

    let title = "Продолжим разбираться";
    let summary = "Повторите ошибки: каждый контрпример превращает формулировку в понятное правило.";
    if (percent >= 90) {
      title = "Отличная работа!";
      summary = "Вы уверенно отличаете теоремы от похожих, но неверных формулировок.";
    } else if (percent >= 75) {
      title = "Очень хороший результат";
      summary = "Основа крепкая. Разберите оставшиеся ошибки — и ловушки задания №19 перестанут мешать.";
    } else if (percent >= 60) {
      title = "Хорошее начало";
      summary = "Большая часть правил уже узнаётся. Режим повторения поможет закрепить сложные формулировки.";
    }

    elements.resultRing.style.setProperty("--score", String(percent));
    elements.resultPercent.textContent = `${percent}%`;
    elements.resultsTitle.textContent = title;
    elements.resultsSummary.textContent = summary;
    elements.resultCorrect.textContent = String(correct);
    elements.resultWrong.textContent = String(wrong);
    elements.resultStreak.textContent = String(bestStreak);
    showScreen("results");
    runHaptic(percent >= 75 ? "success" : "warning");
  }

  function openNavigator() {
    elements.navigatorGrid.replaceChildren();
    state.queue.forEach((question, queueIndex) => {
      const button = document.createElement("button");
      const response = state.answers.get(question.id);
      button.type = "button";
      button.className = "navigator-button";
      button.textContent = String(question.id);
      button.setAttribute("aria-label", `Перейти к утверждению №${question.id}`);
      if (queueIndex === state.index) button.classList.add("is-current");
      if (response?.isCorrect) button.classList.add("is-correct");
      if (response && !response.isCorrect) button.classList.add("is-wrong");
      button.addEventListener("click", () => {
        state.index = queueIndex;
        renderQuestion();
        closeModal(elements.navigatorModal);
      });
      elements.navigatorGrid.append(button);
    });
    openModal(elements.navigatorModal);
  }

  function updateStats() {
    const availableIds = new Set(getAvailableQuestions().map((question) => String(question.id)));
    const studied = Object.keys(state.progress.questions).filter((id) => availableIds.has(id)).length;
    const accuracy = state.progress.totalAnswers > 0
      ? `${Math.round((state.progress.totalCorrect / state.progress.totalAnswers) * 100)}%`
      : "—";
    elements.statsStudied.textContent = `${studied} / ${getAvailableQuestions().length}`;
    elements.statsAnswers.textContent = String(state.progress.totalAnswers);
    elements.statsAccuracy.textContent = accuracy;
    elements.statsMistakes.textContent = String(state.progress.mistakes.length);
  }

  function updateMistakesCaption() {
    const availableIds = new Set(getAvailableQuestions().map((question) => question.id));
    const count = state.progress.mistakes.filter((id) => availableIds.has(id)).length;
    elements.mistakesCaption.textContent = count === 0
      ? "Ошибок пока нет"
      : `${pluralize(count, "утверждение", "утверждения", "утверждений")} на повторе`;
  }

  function pluralize(number, one, few, many) {
    const absolute = Math.abs(number) % 100;
    const last = absolute % 10;
    const form = absolute > 10 && absolute < 20 ? many : last === 1 ? one : last >= 2 && last <= 4 ? few : many;
    return `${number} ${form}`;
  }

  function resetStats() {
    const confirmed = window.confirm("Сбросить всю статистику и список ошибок? Это действие нельзя отменить.");
    if (!confirmed) return;
    state.progress = emptyProgress();
    saveProgress();
    updateStats();
    showToast("Статистика сброшена.");
  }

  function openModal(modal) {
    state.lastFocusedElement = document.activeElement;
    modal.classList.add("is-open");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    const firstButton = modal.querySelector("button:not(.modal__backdrop)");
    window.setTimeout(() => firstButton?.focus(), 30);
  }

  function closeModal(modal) {
    if (!modal.classList.contains("is-open")) return;
    modal.classList.remove("is-open");
    modal.setAttribute("aria-hidden", "true");
    if (!document.querySelector(".modal.is-open")) document.body.classList.remove("modal-open");
    state.lastFocusedElement?.focus?.();
  }

  function closeAllModals() {
    document.querySelectorAll(".modal.is-open").forEach(closeModal);
  }

  function showToast(message) {
    elements.toast.textContent = message;
    elements.toast.classList.add("is-visible");
    window.clearTimeout(state.toastTimer);
    state.toastTimer = window.setTimeout(() => elements.toast.classList.remove("is-visible"), 3200);
  }

  function drawRoundedRect(context, x, y, width, height, radius) {
    const safeRadius = Math.min(radius, width / 2, height / 2);
    context.beginPath();
    context.moveTo(x + safeRadius, y);
    context.arcTo(x + width, y, x + width, y + height, safeRadius);
    context.arcTo(x + width, y + height, x, y + height, safeRadius);
    context.arcTo(x, y + height, x, y, safeRadius);
    context.arcTo(x, y, x + width, y, safeRadius);
    context.closePath();
  }

  function createStoryImage({ percent, correct, wrong, streak, total }) {
    const canvas = document.createElement("canvas");
    canvas.width = 1080;
    canvas.height = 1920;
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Canvas is unavailable");

    const background = context.createLinearGradient(0, 0, 1080, 1920);
    background.addColorStop(0, "#061728");
    background.addColorStop(0.58, "#09243d");
    background.addColorStop(1, "#04111f");
    context.fillStyle = background;
    context.fillRect(0, 0, 1080, 1920);

    const glow = context.createRadialGradient(760, 620, 30, 760, 620, 690);
    glow.addColorStop(0, "rgba(67, 193, 244, 0.24)");
    glow.addColorStop(1, "rgba(67, 193, 244, 0)");
    context.fillStyle = glow;
    context.fillRect(0, 0, 1080, 1400);

    context.strokeStyle = "rgba(109, 205, 247, 0.08)";
    context.lineWidth = 1;
    for (let x = 0; x <= 1080; x += 72) {
      context.beginPath();
      context.moveTo(x, 0);
      context.lineTo(x, 1920);
      context.stroke();
    }
    for (let y = 0; y <= 1920; y += 72) {
      context.beginPath();
      context.moveTo(0, y);
      context.lineTo(1080, y);
      context.stroke();
    }

    context.fillStyle = "#ff4c57";
    context.shadowColor = "rgba(255, 76, 87, 0.55)";
    context.shadowBlur = 28;
    context.fillRect(76, 92, 34, 34);
    context.fillStyle = "#ffc54d";
    context.fillRect(76, 136, 34, 34);
    context.fillStyle = "#ff8a3d";
    context.fillRect(120, 136, 34, 34);
    context.shadowBlur = 0;

    context.fillStyle = "#f5f8fc";
    context.font = "700 34px Arial, sans-serif";
    context.fillText("ФИЗМАТ ПОЙМА", 190, 128);
    context.fillStyle = "#8ea5ba";
    context.font = "400 24px Arial, sans-serif";
    context.fillText("математика · физика · информатика", 190, 164);

    context.textAlign = "center";
    context.fillStyle = "#ffc54d";
    context.font = "700 28px Arial, sans-serif";
    context.fillText("ОГЭ 2027 · ГЕОМЕТРИЯ · ЗАДАНИЕ №19", 540, 300);
    context.fillStyle = "#f5f8fc";
    context.font = "700 58px Arial, sans-serif";
    context.fillText("МОЙ РЕЗУЛЬТАТ", 540, 385);

    const centerX = 540;
    const centerY = 710;
    const radius = 214;
    context.lineCap = "round";
    context.strokeStyle = "rgba(130, 158, 181, 0.24)";
    context.lineWidth = 34;
    context.beginPath();
    context.arc(centerX, centerY, radius, 0, Math.PI * 2);
    context.stroke();
    context.strokeStyle = "#ffc54d";
    context.shadowColor = "rgba(255, 197, 77, 0.42)";
    context.shadowBlur = 34;
    context.beginPath();
    context.arc(centerX, centerY, radius, -Math.PI / 2, -Math.PI / 2 + (Math.PI * 2 * percent) / 100);
    context.stroke();
    context.shadowBlur = 0;

    context.fillStyle = "#ffffff";
    context.font = "700 116px Arial, sans-serif";
    context.fillText(`${percent}%`, centerX, centerY + 30);
    context.fillStyle = "#94a9bd";
    context.font = "600 25px Arial, sans-serif";
    context.fillText("ТОЧНОСТЬ", centerX, centerY + 86);

    const metricY = 1050;
    const metricWidth = 280;
    const metricGap = 24;
    const metrics = [
      { label: "ВЕРНО", value: `${correct} из ${total}` },
      { label: "ОШИБОК", value: String(wrong) },
      { label: "ЛУЧШАЯ СЕРИЯ", value: String(streak) }
    ];
    metrics.forEach((metric, index) => {
      const x = 96 + index * (metricWidth + metricGap);
      drawRoundedRect(context, x, metricY, metricWidth, 190, 30);
      context.fillStyle = "rgba(11, 42, 68, 0.88)";
      context.fill();
      context.strokeStyle = "rgba(104, 198, 240, 0.28)";
      context.lineWidth = 2;
      context.stroke();
      context.fillStyle = "#91a8bb";
      context.font = "600 21px Arial, sans-serif";
      context.fillText(metric.label, x + metricWidth / 2, metricY + 60);
      context.fillStyle = "#ffffff";
      context.font = "700 48px Arial, sans-serif";
      context.fillText(metric.value, x + metricWidth / 2, metricY + 132);
    });

    drawRoundedRect(context, 96, 1315, 888, 270, 38);
    context.fillStyle = "rgba(10, 36, 60, 0.94)";
    context.fill();
    context.strokeStyle = "rgba(255, 197, 77, 0.56)";
    context.lineWidth = 2;
    context.stroke();
    context.fillStyle = "#ffc54d";
    context.font = "700 24px Arial, sans-serif";
    context.fillText("УТВЕРЖДЕНИЯ БЕЗ УГАДЫВАНИЯ", 540, 1380);
    context.fillStyle = "#f5f8fc";
    context.font = "700 43px Arial, sans-serif";
    context.fillText("А вы отличите теорему", 540, 1455);
    context.fillText("от похожей формулировки?", 540, 1515);

    drawRoundedRect(context, 190, 1650, 700, 110, 55);
    const button = context.createLinearGradient(190, 1650, 890, 1760);
    button.addColorStop(0, "#75d5f6");
    button.addColorStop(1, "#43b9ea");
    context.fillStyle = button;
    context.fill();
    context.fillStyle = "#061728";
    context.font = "700 32px Arial, sans-serif";
    context.fillText("ОТКРЫТЬ ТРЕНАЖЁР", 540, 1720);

    context.fillStyle = "#70889e";
    context.font = "400 23px Arial, sans-serif";
    context.fillText("vk.com/app54782047", 540, 1840);
    context.textAlign = "start";

    return canvas.toDataURL("image/png");
  }

  async function shareResult() {
    const percentText = elements.resultPercent.textContent;
    const percent = Number.parseInt(percentText, 10) || 0;
    const correct = Number.parseInt(elements.resultCorrect.textContent, 10) || 0;
    const wrong = Number.parseInt(elements.resultWrong.textContent, 10) || 0;
    const streak = Number.parseInt(elements.resultStreak.textContent, 10) || 0;
    const total = state.queue.length;
    const text = `Мой результат в тренажёре «ОГЭ-2027 · Задание №19»: ${correct} из ${total} (${percent}%). Физмат Пойма`;
    const shareText = `${text}\n${VK_APP_URL}`;
    const shareData = { title: "ОГЭ-2027 · Задание №19", text, url: VK_APP_URL };

    if (window.vkBridge?.send && state.vkReady) {
      try {
        const storyImage = createStoryImage({ percent, correct, wrong, streak, total });
        await window.vkBridge.send("VKWebAppShowStoryBox", {
          background_type: "image",
          blob: storyImage,
          locked: true,
          attachment: {
            text: "open",
            type: "url",
            url: VK_APP_URL
          }
        });
        return;
      } catch (error) {
        const reason = `${error?.error_type || ""} ${error?.error_data?.error_reason || ""}`.toLowerCase();
        if (reason.includes("cancel")) return;

        try {
          await window.vkBridge.send("VKWebAppShowWallPostBox", {
            message: text,
            attachments: VK_APP_URL
          });
          return;
        } catch {
          try {
            await window.vkBridge.send("VKWebAppCopyText", { text: shareText });
            showToast("Результат и ссылка скопированы.");
            return;
          } catch {
            // If the VK client cannot publish or copy, continue with browser fallbacks.
          }
        }
      }
    }

    if (navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch (error) {
        if (error?.name === "AbortError") return;
      }
    }

    if (navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(shareText);
        showToast("Результат и ссылка скопированы.");
        return;
      } catch {
        // A final readable fallback is shown below.
      }
    }

    showToast("Не удалось открыть меню публикации. Скопируйте ссылку на приложение вручную.");
  }

  async function initVKBridge() {
    if (!window.vkBridge?.send) return;
    try {
      await window.vkBridge.send("VKWebAppInit");
      state.vkReady = true;
      window.vkBridge.send("VKWebAppSetTitle", { title: "ОГЭ №19 · Физмат Пойма" }).catch(() => {});
      await grantManagerAccess();
      await loadVKProgress();
    } catch {
      // Outside VK the app works as an ordinary responsive website.
    }
  }

  function setPremiumAccess(enabled, source = state.accessSource) {
    state.premiumAccess = Boolean(enabled);
    state.accessSource = state.premiumAccess ? source : null;
    try {
      if (state.premiumAccess) sessionStorage.setItem(ACCESS_SESSION_KEY, "1");
      else sessionStorage.removeItem(ACCESS_SESSION_KEY);
    } catch {
      // Session storage is an optional convenience; VK remains the source of truth.
    }

    elements.accessCard.classList.toggle("is-active", state.premiumAccess);
    elements.premiumModeCard.classList.toggle("is-unlocked", state.premiumAccess);
    elements.accessTitle.textContent = state.premiumAccess ? "Полный доступ открыт" : "Полный доступ по VK Donut";
    elements.accessCaption.textContent = state.premiumAccess
      ? state.accessSource === "owner"
        ? "Доступ владельца · все 85 утверждений и режимы"
        : state.accessSource === "manager"
          ? "Доступ администратора · все 85 утверждений и режимы"
          : "Доступны все 85 утверждений и режимы"
      : "Уровень «На тренажёры» · 150 ₽ в месяц";
    elements.checkAccessButton.textContent = state.premiumAccess ? "Доступ активен" : "Проверить подписку";
    elements.premiumBadge.textContent = state.premiumAccess ? "ДОСТУП" : "DONUT";
    updateMistakesCaption();
    updateProgressSummary();
  }

  function launchValue(launchParams, key) {
    const queryValue = new URLSearchParams(window.location.search).get(key);
    return launchParams?.[key] ?? queryValue;
  }

  function addUserId(target, value) {
    const userId = Number(value);
    if (Number.isSafeInteger(userId) && userId > 0) target.add(userId);
  }

  function addUserIdsFromUrl(target, url) {
    if (!url) return;
    try {
      const parsed = new URL(url, window.location.href);
      const parameterSets = [
        parsed.searchParams,
        new URLSearchParams(parsed.hash.replace(/^#\??/, ""))
      ];
      parameterSets.forEach((parameters) => {
        ["vk_user_id", "vk_viewer_id", "viewer_id", "user_id"].forEach((key) => {
          addUserId(target, parameters.get(key));
        });
      });
    } catch {
      // Ignore malformed referrer or launch URLs.
    }
  }

  async function accessFromLaunchParams(launchParams) {
    const userIds = new Set();
    ["vk_user_id", "vk_viewer_id", "viewer_id", "user_id", "id"].forEach((key) => {
      addUserId(userIds, launchParams?.[key]);
      addUserId(userIds, launchParams?.response?.[key]);
    });
    addUserIdsFromUrl(userIds, window.location.href);
    addUserIdsFromUrl(userIds, document.referrer);

    try {
      const user = await window.vkBridge.send("VKWebAppGetUserInfo");
      ["id", "user_id", "vk_user_id"].forEach((key) => {
        addUserId(userIds, user?.[key]);
        addUserId(userIds, user?.response?.[key]);
      });
    } catch {
      // Signed launch parameters collected above remain available as a fallback.
    }
    if (userIds.has(OWNER_VK_ID)) return "owner";

    const groupId = Number(launchValue(launchParams, "vk_group_id"));
    const role = String(launchValue(launchParams, "vk_viewer_group_role") || "").toLowerCase();
    if (groupId === COMMUNITY_ID && COMMUNITY_MANAGER_ROLES.has(role)) return "manager";
    return null;
  }

  async function getLaunchParams() {
    try {
      return await window.vkBridge.send("VKWebAppGetLaunchParams");
    } catch {
      return {};
    }
  }

  async function grantManagerAccess(launchParams) {
    const params = launchParams || await getLaunchParams();
    const source = await accessFromLaunchParams(params);
    if (!source) return false;
    setPremiumAccess(true, source);
    return true;
  }

  async function checkDonutAccess() {
    const buttons = [elements.checkAccessButton, elements.premiumCheckButton];
    buttons.forEach((button) => {
      button.disabled = true;
      button.dataset.originalText = button.textContent;
      button.textContent = "Проверяем…";
    });

    try {
      if (!window.vkBridge?.send || !state.vkReady) {
        throw new Error("VK_NOT_READY");
      }

      const launchParams = await getLaunchParams();
      if (await grantManagerAccess(launchParams)) {
        closeModal(elements.premiumModal);
        showToast(state.accessSource === "owner"
          ? "Доступ владельца подтверждён. Все 85 утверждений открыты!"
          : "Доступ администратора подтверждён. Все 85 утверждений открыты!");
        runHaptic("success");
        return;
      }
      const queryAppId = new URLSearchParams(window.location.search).get("vk_app_id");
      const appId = Number(launchParams?.vk_app_id || queryAppId);
      if (!Number.isInteger(appId) || appId <= 0) throw new Error("VK_APP_ID_MISSING");

      const auth = await window.vkBridge.send("VKWebAppGetAuthToken", {
        app_id: appId,
        scope: ""
      });
      if (!auth?.access_token) throw new Error("VK_AUTH_FAILED");

      const apiResult = await window.vkBridge.send("VKWebAppCallAPIMethod", {
        method: "donut.isDon",
        request_id: `donut-${Date.now()}`,
        params: {
          owner_id: -COMMUNITY_ID,
          access_token: auth.access_token,
          v: "5.199"
        }
      });

      const response = apiResult?.response;
      const isDon = response === 1 || response === true || response?.is_don === 1 || response?.is_don === true;
      setPremiumAccess(isDon);

      if (isDon) {
        closeModal(elements.premiumModal);
        showToast("Подписка подтверждена. Все 85 утверждений открыты!");
        runHaptic("success");
      } else {
        showToast("Подписка «На тренажёры» не найдена. Если вы только что оплатили её, повторите проверку через минуту.");
      }
    } catch {
      showToast("Проверка подписки доступна при запуске тренажёра внутри ВКонтакте.");
    } finally {
      buttons.forEach((button) => {
        button.disabled = false;
        button.textContent = state.premiumAccess ? "Доступ активен" : button.dataset.originalText;
        delete button.dataset.originalText;
      });
    }
  }

  async function openDonutSubscription() {
    if (window.vkBridge?.send && state.vkReady) {
      try {
        await window.vkBridge.send("VKWebAppOpenURL", { url: DONUT_URL });
        return;
      } catch {
        // Continue with a browser tab fallback without replacing the Mini App.
      }
    }

    const opened = window.open(DONUT_URL, "_blank", "noopener,noreferrer");
    if (!opened) {
      showToast("Откройте страницу подписки через меню ВКонтакте: Физмат Пойма → VK Donut.");
    }
  }

  function runHaptic(type) {
    if (!window.vkBridge?.send) return;
    window.vkBridge.send("VKWebAppTapticNotificationOccurred", { type }).catch(() => {});
  }

  async function clearLegacyOfflineCache() {
    if ("serviceWorker" in navigator && window.isSecureContext) {
      try {
        const registrations = await navigator.serviceWorker.getRegistrations();
        await Promise.all(registrations.map((registration) => registration.unregister()));
      } catch {
        // The online Mini App continues to work even if cleanup is unavailable.
      }
    }
    if ("caches" in window) {
      try {
        const cacheNames = await caches.keys();
        await Promise.all(cacheNames.map((cacheName) => caches.delete(cacheName)));
      } catch {
        // Cache cleanup is best-effort only.
      }
    }
  }

  function bindEvents() {
    document.querySelectorAll("[data-mode]").forEach((button) => {
      button.addEventListener("click", () => startMode(button.dataset.mode));
    });

    elements.answerButtons.forEach((button) => {
      button.addEventListener("click", () => answerQuestion(button.dataset.answer === "true"));
    });

    elements.nextButton.addEventListener("click", goNext);
    elements.previousButton.addEventListener("click", goPrevious);
    elements.exitQuizButton.addEventListener("click", goHome);
    elements.brandButton.addEventListener("click", goHome);
    elements.openNavigatorButton.addEventListener("click", openNavigator);
    elements.openStatsButton.addEventListener("click", () => {
      updateStats();
      openModal(elements.statsModal);
    });
    elements.resetStatsButton.addEventListener("click", resetStats);
    elements.checkAccessButton.addEventListener("click", checkDonutAccess);
    elements.premiumCheckButton.addEventListener("click", checkDonutAccess);
    elements.subscribeButton.addEventListener("click", openDonutSubscription);
    elements.retryButton.addEventListener("click", () => startMode(state.mode));
    elements.shareButton.addEventListener("click", shareResult);
    elements.resultsHomeButton.addEventListener("click", goHome);

    document.querySelectorAll("[data-close-modal]").forEach((button) => {
      button.addEventListener("click", () => closeModal(button.closest(".modal")));
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        closeAllModals();
        return;
      }
      if (!screens.quiz.classList.contains("screen--active") || document.querySelector(".modal.is-open")) return;

      const question = currentQuestion();
      const answered = question && state.answers.has(question.id);
      if (!answered && (event.key.toLowerCase() === "v" || event.key === "ArrowLeft")) answerQuestion(true);
      if (!answered && (event.key.toLowerCase() === "n" || event.key === "ArrowRight")) answerQuestion(false);
      if (answered && (event.key === "Enter" || event.key === "ArrowDown")) goNext();
    });
  }

  validateDataset();
  bindEvents();
  setPremiumAccess(state.premiumAccess);
  updateMistakesCaption();
  updateProgressSummary();
  window.addEventListener("vkbridge-ready", initVKBridge, { once: true });
  initVKBridge();
  clearLegacyOfflineCache();
})();
